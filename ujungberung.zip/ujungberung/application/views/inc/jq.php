<?php
// Ensure PHP tag is closed properly
?>

<!DOCTYPE HTML>
<html>
  <head>
    <!-- You can add metadata or links to stylesheets here -->
  </head>
  <body>
    <!-- jQuery -->
    <script src="js/jquery.min.js" type="text/javascript"></script>
    
    <!-- jQuery UI -->
    <script src="js/jquery-ui.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    
    <!-- Chart.js -->
    <script src="js/chart.min.js" type="text/javascript"></script>
    
    <!-- Sidebar functionality -->
    <script src="js/sidebar.js" type="text/javascript"></script>
  </body>
</html>
