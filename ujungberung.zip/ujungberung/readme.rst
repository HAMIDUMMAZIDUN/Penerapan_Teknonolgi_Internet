
# Tugas Pertemuan 6 Ppenerapan Teknologi Internet

HAMID ABDUL AZIZ NIM 10122038 IF1

<h2 id="layout">🎨 Hasil Visualisasi dan isi pada menu Produk</h2>

<p align="center">

<img src="https://github.com/clyke02/tugas-pti/blob/f49c4c7ded933c06e8b322a1dcb128bf665a4d40/img/Screenshot%202024-11-06%20160850.png" alt="Ini adalah Hasil Visualisasi Data" width="400px">
<img src="https://github.com/clyke02/tugas-pti/blob/f49c4c7ded933c06e8b322a1dcb128bf665a4d40/img/Screenshot%202024-11-06%20160839.png" alt="Isi dari tabel Produk" width="400px">
</p>
