
# Tugas Pertemuan 6 PTI

HAMID ABDUL AZIZ NIM 10122038 IF1
<p align="center">

<img src="https://github.com/HAMIDUMMAZIDUN/PPenerpan-Teknologi-Internet/blob/main/CHART.png" alt="Ini adalah Hasil Visualisasi Data" width="400px">
<img src="https://github.com/HAMIDUMMAZIDUN/PPenerpan-Teknologi-Internet/blob/main/PRODUK.png" alt="Isi dari tabel Produk" width="400px">
</p>
